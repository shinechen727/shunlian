package trade;

public class Transation {
	
	private Long transationId;
	
	private Long tradeId;
	
	private Integer version;
	
	private SecurityCodeEnum securityCode;
	
	private Long quality;
	
	private OperateEnum operate;
	
	private TradeEnum buyOrSell;
	
	public Long getTransationId() {
		return transationId;
	}

	public void setTransationId(Long transationId) {
		this.transationId = transationId;
	}

	public Long getTradeId() {
		return tradeId;
	}

	public void setTradeId(Long tradeId) {
		this.tradeId = tradeId;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}
	
	public Long getQuality() {
		return quality;
	}

	public void setQuality(Long quality) {
		this.quality = quality;
	}

	public SecurityCodeEnum getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(SecurityCodeEnum securityCode) {
		this.securityCode = securityCode;
	}

	public OperateEnum getOperate() {
		return operate;
	}

	public void setOperate(OperateEnum operate) {
		this.operate = operate;
	}

	public TradeEnum getBuyOrSell() {
		return buyOrSell;
	}

	public void setBuyOrSell(TradeEnum buyOrSell) {
		this.buyOrSell = buyOrSell;
	}

	
	
	

}
