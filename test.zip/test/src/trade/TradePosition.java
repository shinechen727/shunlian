package trade;

public class TradePosition {
	
	private SecurityCodeEnum securityCode;
	
	private Long quality;

}
