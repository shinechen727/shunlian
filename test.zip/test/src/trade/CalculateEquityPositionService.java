package trade;

import java.util.List;

public interface CalculateEquityPositionService {
	
	List<TradePosition> getPositionBySecurityCode(List<Transation> tranctions);

}
