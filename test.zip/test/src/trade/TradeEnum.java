package trade;

public enum TradeEnum {
	Buy,Sell

}
