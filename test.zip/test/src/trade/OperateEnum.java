package trade;

public enum OperateEnum {
	INSERT,
	UPDATE,
	CANCEL

}
