package trade;

public enum SecurityCodeEnum {
	
	REL,
	ITC,
	INF

}
